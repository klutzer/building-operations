import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class NovoGeradorObservacao {

	private static final String NOTA_UNICA = "Fatura da nota fiscal de simples remessa: ";
	private static final String NOTAS_MULTIPLAS = "Fatura das notas fiscais de simples remessa: ";

	public String geraObservacao(List<Integer> notas) {
		return notas.isEmpty() ? "" : descreverCodigos(new ArrayList<>(notas)) + ".";
	}

	private String descreverCodigos(List<Integer> lista) {
		Integer ultimaNota = lista.remove(lista.size()-1);
		String notas = juntarItens(lista);
		return notas.isEmpty() ? NOTA_UNICA + ultimaNota : NOTAS_MULTIPLAS + notas + " e " + ultimaNota;
	}
	
	private String juntarItens(List<Integer> lista) {
		return lista.stream()
			.map(String::valueOf)
			.collect(Collectors.joining(", "));
	}
}