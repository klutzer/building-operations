
import java.util.Iterator;
import java.util.List;

/*
 * Uma classe que cont�m muitos coment�rios, obviamente n�o est� clara o suficiente para
 * o pr�prio c�digo nos dizer o que ela faz. Isso faz com que seja perdido mais tempo
 * para outro desenvolvedor entender o que o c�digo faz, pois o coment�rio pode mentir, mas o c�digo n�o.
 * 
 * Todos os coment�rios originais desta classe foram apagados e inseridos novos apenas para 
 * destacar os problemas que foram encontrados. A classe nova � a "NovoGeradorObservacao".
 * O teste tamb�m foi copiado, mas foi mantido igual ao original, exceto nas linhas 12 e 16, onde a inst�ncia
 * referenciava a classe antiga
 * 
 */
public class GeradorObservacao { 

	//Nome de vari�vel n�o segue a conven��o Java. Neste caso o nome deveria estar em MAI�SCULO
	static final String umoNota = "Fatura da nota fiscal de simples remessa: ";
	//N�o h� necessidade de uma vari�vel de inst�ncia para este c�digo
	String texto;
		
	/*
	 * � recomendado que o par�metro "List" seja tipado. Desta forma que est�,
	 * n�o sabemos que tipo de dados vai chegar e pode comprometer a implementa��o ou
	 * gerar erros de Cast na medida em que o c�digo tivesse modifica��es
	 */
	public String geraObservacao(List lista) 
	{
		texto = "";
		if (!lista.isEmpty()) 
		{
			return retornaCodigos(lista) + ".";
		}		
		return "";		
	}

	private String retornaCodigos(List lista) {
		if (lista.size() >= 2) {
			/*
			 * XXX N�o h� motivo para existir apenas a constante para a nota simples.
			 * Ambas poderiam ser constantes
			 */
			texto = "Fatura das notas fiscais de simples remessa: ";
		} else {
			texto = umoNota;
		}
		
		//Olhando para a vari�vel, n�o da pra identificar o que ela armazena
		StringBuilder cod = new StringBuilder();
		for (Iterator<Integer> iterator = lista.iterator(); iterator.hasNext();) {
			//Nome de vari�vel confuso
			Integer c = iterator.next();
			/*
			 * Mais uma.. e n�o h� necessidade de criar essa String, daria pra utilizar o pr�prio 
			 * StringBuilder criado e fazer o append nele
			 */
			String s = "";
			/*
			 * cod.toString() nunca retornar� nulo, e � poss�vel pegar o length sem converter para String,
			 * o que gera mais processamento (agravado ainda por estar sendo feito duas vezes, e no meio de
			 * um la�o)
			 */
			if( cod.toString() == null || cod.toString().length() <= 0 )
				s =  "";
				//Indenta��o n�o est� nivelada corretamente (pode ser devido � tabula��o)
				else if( iterator.hasNext() )
					s =  ", ";
				else
					s =  " e ";
			
			cod.append(s + c);
		}
		
		return texto + cod;
	}
}